package com.example.examen;

import androidx.appcompat.app.AppCompatActivity;

import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.widget.TextView;

public class TerceraActividad extends AppCompatActivity {
    TextView tvDatos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tercera_actividad);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        recibiDatos();
    }
    public void recibiDatos(){
        Bundle extras = getIntent().getExtras();
        String Dato1= extras.getString("dato");
        String Dato2= extras.getString("dato2");
        tvDatos = (TextView) findViewById(R.id.textView3);
        if (Dato1=="Peperoni") {
            tvDatos.setText(Dato1 +"-"+ Dato2 + "Total: 50");
        }
        if (Dato1=="Haiana") {
            tvDatos.setText(Dato1 +"-"+ Dato2 + "Total: 55");
        }
        if (Dato1=="Vegetariana") {
            tvDatos.setText(Dato1 +"-"+ Dato2 + "Total: 45");
        }
    }
}