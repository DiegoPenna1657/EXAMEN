package com.example.examen;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;

import org.w3c.dom.Text;

public class SegundaActividad extends AppCompatActivity {
    String ha="Hawaiana" ;
    String pe="Peperoni" ;
    String ve="Vegetariano";

    String co="Coca-Cola" ;
    String fa="Fanta" ;
    String sp="Sprite";
    private int total;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

    }

    public void onClick(View view) {
        startActivity(new Intent("com.example.TerceraActividad"));
    }
    public void miClicManejador(View view) {
        switch (view.getId()) {
            case R.id.button:

                RadioButton gaCoca = (RadioButton)
                        findViewById(R.id.Coca);

                RadioButton gaSpri = (RadioButton)
                        findViewById(R.id.sprite);

                RadioButton gaFant = (RadioButton)
                        findViewById(R.id.fanta);

                if (gaCoca.isChecked()) {
                    Intent ga = new Intent( this,SegundaActividad.class);
                    ga.putExtra("dato",co );
                    gaCoca.setChecked(true);
                    gaSpri.setChecked(false);
                    gaFant.setChecked(false);

                }

                if (gaSpri.isChecked()) {
                    Intent ga = new Intent( this,SegundaActividad.class);
                    ga.putExtra("dato",sp );
                    gaCoca.setChecked(false);
                    gaSpri.setChecked(true);
                    gaFant.setChecked(false);
                }
                if (gaFant.isChecked()) {
                    Intent ga = new Intent( this,SegundaActividad.class);
                    ga.putExtra("dato",fa );
                    gaCoca.setChecked(false);
                    gaSpri.setChecked(false);
                    gaFant.setChecked(true);
                }


                break;
        }
        switch (view.getId()) {
            case R.id.button:
                RadioButton pizPepe = (RadioButton)
                        findViewById(R.id.peperoni);

                RadioButton pizHawa = (RadioButton)
                        findViewById(R.id.hawaiana);

                RadioButton pizVege = (RadioButton)
                        findViewById(R.id.vegete);
                                ;
                if (pizPepe.isChecked()) {
                    Intent pi = new Intent( this,SegundaActividad.class);
                    pi.putExtra("dato2",pe );
                    pizPepe.setChecked(true);
                    pizHawa.setChecked(false);
                    pizVege.setChecked(false);

                }

                if (pizHawa.isChecked()) {
                    Intent pi = new Intent( this,SegundaActividad.class);
                    pi.putExtra("dato2",ha );
                    pizPepe.setChecked(false);
                    pizHawa.setChecked(true);
                    pizVege.setChecked(false);
                }
                if (pizVege.isChecked()) {
                    Intent pi = new Intent( this,SegundaActividad.class);
                    pi.putExtra("dato2",ve );
                    pizPepe.setChecked(false);
                    pizHawa.setChecked(false);
                    pizVege.setChecked(true);
                }


                break;
        }
    }





}